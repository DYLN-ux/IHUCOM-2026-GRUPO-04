const nombreUsuario = sessionStorage.getItem("megax_usuario");
if (nombreUsuario == null) {
  window.location.href = "index.html";
}

document.querySelector(".usuario span").textContent = nombreUsuario;
document.querySelector(".usuario a").onclick = function () {
  sessionStorage.removeItem("megax_usuario");
};



// Lista de máquinas. 
let maquinas = JSON.parse(localStorage.getItem("gym_maquinas"));

if (maquinas == null) {
  maquinas = [
    { nombre: "Caminadora", piso: "Primero", estado: "Operativo", ultimoMant: "2026-03-20", compra: "2024-01-15", descripcion: "", imagen: "imagenes/caminadora.jpeg" },
    { nombre: "Bicicleta", piso: "Primero", estado: "Operativo", ultimoMant: "2026-05-12", compra: "2024-01-15", descripcion: "", imagen: "imagenes/bicicleta.jpeg" },
    { nombre: "Elíptica", piso: "Primero", estado: "Operativo", ultimoMant: "2026-05-12", compra: "2024-01-15", descripcion: "", imagen: "imagenes/eliptica.jpeg" },
    { nombre: "Prensa", piso: "Segundo", estado: "Operativo", ultimoMant: "2026-03-20", compra: "2024-01-15", descripcion: "", imagen: "imagenes/prensa.jpeg" },
    { nombre: "Press banca", piso: "Segundo", estado: "En mantenimiento", ultimoMant: "2024-12-17", compra: "2024-01-15", descripcion: "", imagen: "imagenes/pressbanca.jpeg" },
    { nombre: "Banca ajustable", piso: "Segundo", estado: "Operativo", ultimoMant: "2026-03-20", compra: "2024-01-15", descripcion: "", imagen: "imagenes/banca.jpeg" },
    { nombre: "Pec fly", piso: "Segundo", estado: "Operativo", ultimoMant: "2023-12-18", compra: "2024-01-15", descripcion: "", imagen: "imagenes/pec.jpeg" },
    { nombre: "Curl femoral", piso: "Segundo", estado: "Operativo", ultimoMant: "2026-01-16", compra: "2024-01-15", descripcion: "", imagen: "imagenes/curlfemoral.jpg" }
  ];
  guardarMaquinas();
}

const imagenesPorNombre = {
  "Caminadora": "imagenes/caminadora.jpeg",
  "Bicicleta": "imagenes/bicicleta.jpeg",
  "Elíptica": "imagenes/eliptica.jpeg",
  "Prensa": "imagenes/prensa.jpeg",
  "Press banca": "imagenes/pressbanca.jpeg",
  "Banca ajustable": "imagenes/banca.jpeg",
  "Pec fly": "imagenes/pec.jpeg",
  "Curl femoral": "imagenes/curlfemoral.jpg"
};
for (let i = 0; i < maquinas.length; i++) {
  if (maquinas[i].imagen == "" && imagenesPorNombre[maquinas[i].nombre]) {
    maquinas[i].imagen = imagenesPorNombre[maquinas[i].nombre];
  }
}
guardarMaquinas();

function guardarMaquinas() {
  localStorage.setItem("gym_maquinas", JSON.stringify(maquinas));
}

let pisoActual = "Primero";      
let posicionSeleccionada = -1;   
let modo = "agregar";            
let imagenActual = "";           
const formulario = document.getElementById("f");


function formatoFecha(texto){
  const partes = texto.split("-");
  return partes[2] + "/" + partes[1] + "/" + partes[0];
}

function htmlImagen(imagen){
  if (imagen != "") {
    return "<img class='img' src='" + imagen + "'>";
  }
  return "<div class='ph'>-</div>";
}


function mostrarMaquinas(){
  let html = "";

  for (let i = 0; i < maquinas.length; i++){
    const maquina = maquinas[i];

    if (maquina.piso == pisoActual){

      let claseTarjeta = "card";
      if (i == posicionSeleccionada){
        claseTarjeta = "card sel";
      }

      html += "<div class='" + claseTarjeta + "' onclick='elegirMaquina(" + i + ")'>";
      html += htmlImagen(maquina.imagen);
      html += "<h3>" + maquina.nombre + "</h3>";
      html += "Estado: " + maquina.estado + "<br>";
      html += "Último mantenimiento:<br>" + formatoFecha(maquina.ultimoMant) + "<br>";
      html += "<a href='#' onclick='reportarMantenimiento(" + i + "); event.stopPropagation(); return false;'>Reportar mantenimiento</a>";
      html += "</div>";
    }
  }

  if (html == "") {
    html = "<p>No hay máquinas en este piso.</p>";
  }
  document.getElementById("grid").innerHTML = html;

  const pestanas = document.querySelectorAll("#tabs button");
  for (let i = 0; i < pestanas.length; i++){
    if (pestanas[i].getAttribute("data-p") == pisoActual){
      pestanas[i].classList.add("on");
    } else {
      pestanas[i].classList.remove("on");
    }
  }
}

function elegirMaquina(posicion) {
  posicionSeleccionada = posicion;
  mostrarMaquinas();
}

// Primer piso y Segundo piso
const botonesPiso = document.querySelectorAll("#tabs button");
for (let i = 0; i < botonesPiso.length; i++) {
  botonesPiso[i].onclick = function () {
    pisoActual = this.getAttribute("data-p");
    posicionSeleccionada = -1;
    mostrarMaquinas();
  };
}

function mostrarLista() {
  document.getElementById("v-list").hidden = false;
  document.getElementById("v-form").hidden = true;
  document.getElementById("ttl").textContent = "Control Inventario Máquinas";
  mostrarMaquinas();
}

function mostrarFormulario(titulo) {
  document.getElementById("v-list").hidden = true;
  document.getElementById("v-form").hidden = false;
  document.getElementById("ttl").textContent = titulo;
}

function llenarFormulario(maquina) {
  formulario.nombre.value = maquina.nombre;
  formulario.piso.value = maquina.piso;
  formulario.ultimoMant.value = maquina.ultimoMant;
  formulario.estado.value = maquina.estado;
  formulario.compra.value = maquina.compra;
  formulario.descripcion.value = maquina.descripcion;
  imagenActual = maquina.imagen;
}

function bloquearCampos(bloquear) {
  for (let i = 0; i < formulario.elements.length; i++) {
    const campo = formulario.elements[i];
    if (campo.name != "" && campo.name != "descripcion") {
      campo.disabled = bloquear;
    }
  }
}

// Botón Agregar máquina 
document.getElementById("bNew").onclick = function () {
  modo = "agregar";
  posicionSeleccionada = -1;
  formulario.reset();
  imagenActual = "";
  document.getElementById("imgTag").innerHTML = htmlImagen("");

  bloquearCampos(false);
  formulario.descripcion.required = false;
  document.getElementById("pick").hidden = false;     
  document.getElementById("bGen").hidden = true;      
  document.getElementById("bSave").hidden = false;
  document.getElementById("bSave").textContent = "Agregar";
  mostrarFormulario("Agregar máquina");
};

// Botón Editar máquina
document.getElementById("bEdit").onclick = function () {
  if (posicionSeleccionada == -1) {
    alert("Selecciona una máquina.");
    return;
  }
  modo = "editar";
  formulario.reset();
  llenarFormulario(maquinas[posicionSeleccionada]);
  document.getElementById("imgTag").innerHTML = htmlImagen(imagenActual);

  bloquearCampos(false);
  formulario.descripcion.required = false;
  document.getElementById("pick").hidden = false;
  document.getElementById("bGen").hidden = true;
  document.getElementById("bSave").hidden = false;
  document.getElementById("bSave").textContent = "Actualizar";
  mostrarFormulario("Editar máquina");
};

// Boton Reportar mantenimiento 
function reportarMantenimiento(posicion) {
  modo = "reportar";
  posicionSeleccionada = posicion;
  formulario.reset();
  llenarFormulario(maquinas[posicion]);
  formulario.descripcion.value = "";   
  document.getElementById("imgTag").innerHTML = htmlImagen(imagenActual);

  bloquearCampos(true);                
  formulario.descripcion.required = true;
  document.getElementById("pick").hidden = true;
  document.getElementById("bGen").hidden = false;
  document.getElementById("bSave").hidden = true;
  mostrarFormulario("Reportar mantenimiento");
}

// Botón Cancelar
document.getElementById("bCancel").onclick = function () {
  mostrarLista();
};

// Botón Adjuntar imagen 
document.getElementById("pick").onclick = function () {
  document.getElementById("file").click();
};

document.getElementById("file").onchange = function () {
  const archivo = this.files[0];
  if (archivo == null) {
    return;
  }

  const lector = new FileReader();
  lector.onload = function (){
    const imagen = new Image();
    imagen.onload = function (){

      let ladoMayor = imagen.width;
      if (imagen.height > ladoMayor){
        ladoMayor = imagen.height;
      }
      let escala = 1;
      if (ladoMayor > 500){
        escala = 500 / ladoMayor;
      }

      const lienzo = document.createElement("canvas");
      lienzo.width = imagen.width * escala;
      lienzo.height = imagen.height * escala;
      lienzo.getContext("2d").drawImage(imagen, 0, 0, lienzo.width, lienzo.height);

      imagenActual = lienzo.toDataURL("image/jpeg", 0.8);
      document.getElementById("imgTag").innerHTML = htmlImagen(imagenActual);
    };
    imagen.src = lector.result;
  };
  lector.readAsDataURL(archivo);
};


// PDF - Generar reporte
function imagenParaPDF(ruta) {
  return new Promise(function (resolver) {
    if (ruta == "") {
      resolver("");
      return;
    }
    if (ruta.indexOf("data:") == 0) {
      resolver(ruta);
      return;
    }
    const img = new Image();
    img.onload = function () {
      try {
        const lienzo = document.createElement("canvas");
        lienzo.width = img.width;
        lienzo.height = img.height;
        lienzo.getContext("2d").drawImage(img, 0, 0);
        resolver(lienzo.toDataURL("image/jpeg", 0.8));
      } catch (error) {
        resolver("");   
      }
    };
    img.onerror = function () { resolver(""); };
    img.src = ruta;
  });
}

function crearPDF(maquina, averia, imagenPDF) {

  const doc = new window.jspdf.jsPDF();
  doc.setFontSize(18);
  doc.text("Megax Gym - Reporte de mantenimiento", 14, 18);
  doc.setFontSize(10);
  doc.text("Generado: " + new Date().toLocaleString() + " | Por: " + nombreUsuario, 14, 25);

  let y = 32;
  if (imagenPDF != "") {
    const medidas = doc.getImageProperties(imagenPDF);
    const ancho = 60;
    const alto = ancho * medidas.height / medidas.width;
    doc.addImage(imagenPDF, "JPEG", 14, y, ancho, alto);
    y = y + alto + 6;
  }

  doc.autoTable({
    startY: y,
    theme: "grid",
    head: [["Campo", "Dato"]],
    headStyles: { fillColor: [0, 0, 0], textColor: [240, 192, 48] },
    body: [
      ["Nombre", maquina.nombre],
      ["Piso", maquina.piso],
      ["Estado", maquina.estado],
      ["Último mantenimiento", formatoFecha(maquina.ultimoMant)],
      ["Fecha de compra", formatoFecha(maquina.compra)]
    ]
  });

  const yTexto = doc.lastAutoTable.finalY + 10;
  doc.setFontSize(12);
  doc.text("Descripción de la avería", 14, yTexto);
  doc.setFontSize(10);
  doc.text(doc.splitTextToSize(averia, 180), 14, yTexto + 7);

  doc.save("reporte-" + maquina.nombre.toLowerCase().replace(/ /g, "-") + ".pdf");
}


formulario.onsubmit = function (evento) {
  evento.preventDefault();

  if (modo == "reportar") {
    const maquinaPDF = maquinas[posicionSeleccionada];
    const averiaPDF = formulario.descripcion.value.trim();
    imagenParaPDF(maquinaPDF.imagen).then(function (imagenPDF) {
      crearPDF(maquinaPDF, averiaPDF, imagenPDF);
      mostrarLista();
    });
    return;
  }

  const datos = {
    nombre: formulario.nombre.value.trim(),
    piso: formulario.piso.value,
    estado: formulario.estado.value,
    ultimoMant: formulario.ultimoMant.value,
    compra: formulario.compra.value,
    descripcion: formulario.descripcion.value.trim(),
    imagen: imagenActual
  };

  if (modo == "agregar") {
    maquinas.push(datos);
  } else {
    maquinas[posicionSeleccionada] = datos;
  }

  try {
    guardarMaquinas();
  } catch (error) {
    alert("No se pudo guardar: la imagen es muy pesada. Prueba con una más pequeña.");
    return;
  }

  pisoActual = datos.piso;   
  posicionSeleccionada = -1;
  mostrarLista();
};

mostrarMaquinas();
