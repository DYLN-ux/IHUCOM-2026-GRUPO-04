const nombreUsuario = sessionStorage.getItem("megax_usuario");
if (nombreUsuario == null) {
  window.location.href = "index.html";
}

document.querySelector(".usuario span").textContent = nombreUsuario;
document.querySelector(".usuario a").onclick = function () {
  sessionStorage.removeItem("megax_usuario");
};


const categorias = ["Hidratante", "Suplemento", "Entrenamiento", "Energizante"];

// Lista de productos. 
let productos = JSON.parse(localStorage.getItem("gym_productos"));
if (productos == null){
  productos = [
    {categoria: "Hidratante", nombre: "SPORADE Mandarina 500ml", codigo: "SPD001", precio: 3, stock: 14, stockMin: 5, entrada: 30, salida: 16},
    {categoria: "Suplemento", nombre: "WHEYPRO DE 1kg Chocolate - Proteína Whey", codigo: "SPD002", precio: 94, stock: 8, stockMin: 2, entrada: 15, salida: 7},
    {categoria: "Energizante", nombre: "Bebida MONSTER Ultra Lata 473ml", codigo: "SPD003", precio: 3, stock: 12, stockMin: 5, entrada: 25, salida: 13},
    {categoria: "Entrenamiento", nombre: "SHAKER Tomatodo Mezclador de Proteína 500 ML", codigo: "SPD004", precio: 3, stock: 14, stockMin: 3, entrada: 20, salida: 6},
    {categoria: "Hidratante", nombre: "SPORADE Tropical 500ml", codigo: "SPD011", precio: 3, stock: 5, stockMin: 5, entrada: 30, salida: 25},
    {categoria: "Suplemento", nombre: "WHEYPRO DE 1kg Vainilla - Proteína Whey", codigo: "SPD012", precio: 94, stock: 9, stockMin: 2, entrada: 15, salida: 6}
  ];
  guardarProductos();
}

function guardarProductos() {
  localStorage.setItem("gym_productos", JSON.stringify(productos));
}

let posicionSeleccionada = -1;  
let modo = "agregar";           
const formulario = document.getElementById("f");

let opcionesCategorias = "";
for (let i = 0; i < categorias.length; i++) {
  opcionesCategorias += "<option>" + categorias[i] + "</option>";
}
document.getElementById("cat").innerHTML = "<option value=''>Categoría (todas)</option>" + opcionesCategorias;
formulario.categoria.innerHTML = "<option value=''>---</option>" + opcionesCategorias;


function tieneStockBajo(producto) {
  return producto.stock <= producto.stockMin;
}

function filtrarProductos(){
  const textoBuscado = document.getElementById("q").value.trim().toLowerCase();
  const categoriaElegida = document.getElementById("cat").value;
  const soloStockBajo = document.getElementById("low").checked;
  const posiciones = [];

  for (let i = 0; i < productos.length; i++){
    const producto = productos[i];
    let cumple = true;

    if (categoriaElegida != "" && producto.categoria != categoriaElegida){
      cumple = false;
    }

    if (soloStockBajo == true && tieneStockBajo(producto) == false){
      cumple = false;
    }

    if (producto.nombre.toLowerCase().includes(textoBuscado) == false){
      cumple = false;
    }

    if (cumple == true) {
      posiciones.push(i);
    }
  }
  return posiciones;
}

function textoEntrada(producto){
  if (producto.entrada > 0){
    return "+" + producto.entrada;
  }
  return "";
}

function textoSalida(producto){
  if (producto.salida > 0){
    return "-" + producto.salida;
  }
  return "";
}


function mostrarTabla() {
  const posiciones = filtrarProductos();
  let html = "";

  for (let j = 0; j < posiciones.length; j++){
    const i = posiciones[j];
    const producto = productos[i];

    let claseFila = "";
    if (i == posicionSeleccionada){
      claseFila = claseFila + "sel ";
    }
    if (tieneStockBajo(producto)){
      claseFila = claseFila + "low";
    }

    html += "<tr class='" + claseFila + "' onclick='elegirFila(" + i + ")'>";
    html += "<td>" + producto.categoria + "</td>";
    html += "<td>" + producto.nombre + "</td>";
    html += "<td>" + producto.codigo + "</td>";
    html += "<td>" + producto.precio.toFixed(2) + "</td>";
    html += "<td>" + producto.stock + "</td>";
    html += "<td>" + producto.stockMin + "</td>";
    html += "<td>" + textoEntrada(producto) + "</td>";
    html += "<td>" + textoSalida(producto) + "</td>";
    html += "</tr>";
  }

  if (html == "") {
    html = "<tr><td colspan='8'>No hay productos con esos filtros.</td></tr>";
  }
  document.getElementById("tb").innerHTML = html;
}

function elegirFila(posicion) {
  posicionSeleccionada = posicion;
  mostrarTabla();
}

document.getElementById("bBuscar").onclick = mostrarTabla;
document.getElementById("q").oninput = mostrarTabla;
document.getElementById("cat").onchange = mostrarTabla;
document.getElementById("low").onchange = mostrarTabla;


// Dashboard
function mostrarDashboard() {
  let totalUnidades = 0;
  let valorInventario = 0;
  let cantidadStockBajo = 0;

  for (let i = 0; i < productos.length; i++) {
    totalUnidades = totalUnidades + productos[i].stock;
    valorInventario = valorInventario + productos[i].precio * productos[i].stock;
    if (tieneStockBajo(productos[i])) {
      cantidadStockBajo = cantidadStockBajo + 1;
    }
  }

  document.getElementById("dTotal").textContent = productos.length;
  document.getElementById("dUnidades").textContent = totalUnidades;
  document.getElementById("dBajo").textContent = cantidadStockBajo;
  document.getElementById("dValor").textContent = "S/ " + valorInventario.toFixed(2);

  let htmlCategorias = "";
  for (let c = 0; c < categorias.length; c++) {
    let unidadesCategoria = 0;
    for (let i = 0; i < productos.length; i++) {
      if (productos[i].categoria == categorias[c]) {
        unidadesCategoria = unidadesCategoria + productos[i].stock;
      }
    }
    htmlCategorias += "<div class='dash-tarjeta'><b>" + unidadesCategoria + "</b><p>" + categorias[c] + "</p></div>";
  }
  document.getElementById("dCategorias").innerHTML = htmlCategorias;
}

function mostrarLista() {
  document.getElementById("v-list").hidden = false;
  document.getElementById("v-form").hidden = true;
  document.getElementById("ttl").textContent = "Control de inventario de productos";
  mostrarTabla();
  mostrarDashboard();
}

function mostrarFormulario(titulo) {
  document.getElementById("v-list").hidden = true;
  document.getElementById("v-form").hidden = false;
  document.getElementById("ttl").textContent = titulo;
}


// PDF - botón Exportar tabla
document.getElementById("bExp").onclick = function () {
  const posiciones = filtrarProductos();
  if (posiciones.length == 0) {
    alert("No hay datos para exportar.");
    return;
  }

  let titulo = "Inventario de productos";
  if (document.getElementById("cat").value != "") {
    titulo = titulo + " (Categoría: " + document.getElementById("cat").value + ")";
  }
  if (document.getElementById("low").checked == true) {
    titulo = titulo + " (Stock bajo)";
  }

  const filas = [];
  for (let j = 0; j < posiciones.length; j++) {
    const p = productos[posiciones[j]];
    filas.push([p.categoria, p.nombre, p.codigo, p.precio.toFixed(2), p.stock, p.stockMin, textoEntrada(p), textoSalida(p)]);
  }

  const doc = new window.jspdf.jsPDF({ orientation: "landscape" });
  doc.setFontSize(16);
  doc.text("Megax Gym - " + titulo, 14, 15);
  doc.setFontSize(9);
  doc.text("Generado: " + new Date().toLocaleString(), 14, 21);
  doc.autoTable({
    startY: 26,
    head: [["Categoría", "Producto", "Código", "Precio unitario", "Stock", "Stock mínimo", "Última entrada", "Salida"]],
    body: filas,
    headStyles: { fillColor: [0, 0, 0], textColor: [240, 192, 48] }
  });
  doc.save("inventario-productos.pdf");
};

// Botón Agregar producto
document.getElementById("bNew").onclick = function () {
  modo = "agregar";
  formulario.reset();

  formulario.stock.disabled = false;
  formulario.entrada.disabled = true;
  formulario.salida.disabled = true;

  document.getElementById("bSave").textContent = "Agregar";
  mostrarFormulario("Agregar producto");
};

// Botón Editar producto
document.getElementById("bEdit").onclick = function () {
  if (posicionSeleccionada == -1) {
    alert("Selecciona un producto de la tabla.");
    return;
  }
  const producto = productos[posicionSeleccionada];

  modo = "editar";
  formulario.reset();
  formulario.nombre.value = producto.nombre;
  formulario.codigo.value = producto.codigo;
  formulario.categoria.value = producto.categoria;
  formulario.precio.value = producto.precio;
  formulario.stock.value = producto.stock;
  formulario.stockMin.value = producto.stockMin;

  formulario.stock.disabled = true;
  formulario.entrada.disabled = false;
  formulario.salida.disabled = false;

  document.getElementById("bSave").textContent = "Actualizar";
  mostrarFormulario("Actualizar producto");
};

// Botón Cancelar
document.getElementById("bCancel").onclick = function () {
  mostrarLista();
};


formulario.onsubmit = function (evento) {
  evento.preventDefault();

  const codigo = formulario.codigo.value.trim().toUpperCase();

  for (let i = 0; i < productos.length; i++) {
    if (productos[i].codigo == codigo) {
      if (modo == "agregar" || i != posicionSeleccionada) {
        alert("Ya existe un producto con ese código.");
        return;
      }
    }
  }

  if (modo == "agregar"){

    const nuevoProducto = {
      categoria: formulario.categoria.value,
      nombre: formulario.nombre.value.trim(),
      codigo: codigo,
      precio: Number(formulario.precio.value),
      stock: Number(formulario.stock.value),
      stockMin: Number(formulario.stockMin.value),
      entrada: 0,
      salida: 0
    };
    productos.push(nuevoProducto);

  } else {

    const producto = productos[posicionSeleccionada];
    const entrada = Number(formulario.entrada.value);
    const salida = Number(formulario.salida.value);

    const nuevoStock = producto.stock + entrada - salida;
    if (nuevoStock < 0) {
      alert("La salida (" + salida + ") es mayor al stock disponible (" + producto.stock + ").");
      return;
    }

    producto.nombre = formulario.nombre.value.trim();
    producto.codigo = codigo;
    producto.categoria = formulario.categoria.value;
    producto.precio = Number(formulario.precio.value);
    producto.stockMin = Number(formulario.stockMin.value);
    producto.stock = nuevoStock;

    if (entrada > 0) { producto.entrada = entrada; }
    if (salida > 0) { producto.salida = salida; }
  }

  guardarProductos();
  posicionSeleccionada = -1;
  mostrarLista();
};

mostrarTabla();
mostrarDashboard();
