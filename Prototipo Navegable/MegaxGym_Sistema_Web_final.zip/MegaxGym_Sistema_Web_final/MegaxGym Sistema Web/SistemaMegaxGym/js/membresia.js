const nombreUsuario = sessionStorage.getItem("megax_usuario");
if (nombreUsuario == null) {
  window.location.href = "index.html";
}

document.querySelector(".usuario span").textContent = nombreUsuario;
document.querySelector(".usuario a").onclick = function () {
  sessionStorage.removeItem("megax_usuario");
};

// Planes de membresías
const planesMeses = [3, 6, 12];
const planesPrecios = [140, 210, 350];

let miembros = JSON.parse(localStorage.getItem("gym_miembros"));

if (miembros == null) {
  miembros = [
    {dni: "73053486", nombres: "Dylan", apellidos: "Tejeda López", inicio: "2025-09-14", fin: "2026-09-14", asistencias: []},
    {dni: "73061350", nombres: "Luz", apellidos: "Huanca Cajuaringa", inicio: "2026-06-01", fin: "2026-09-01", asistencias: []},
    {dni: "73068520", nombres: "Kelly", apellidos: "Bello Julca", inicio: "2025-09-05", fin: "2026-03-05", asistencias: []},
    {dni: "71048667", nombres: "Hade", apellidos: "Coronado Benites", inicio: "2026-02-28", fin: "2027-08-28", asistencias: []},
    {dni: "73053487", nombres: "Sebastian", apellidos: "Camargo Arana", inicio: "2024-04-15", fin: "2024-10-15", asistencias: []}
  ];
  guardarMiembros();
}

function guardarMiembros() {
  localStorage.setItem("gym_miembros", JSON.stringify(miembros));
}

let posicionSeleccionada = -1;  
let modo = "nuevo";             
const formulario = document.getElementById("f");


function fechaATexto(fecha) {
  let mes = fecha.getMonth() + 1;
  let dia = fecha.getDate();
  
  if (mes < 10){ 
    mes = "0" + mes;
  }
  
  if (dia < 10){ 
    dia = "0" + dia; 
  }

  return fecha.getFullYear() + "-" + mes + "-" + dia;
}

function hoy() {
  return fechaATexto(new Date());
}

function formatoFecha(texto) {
  const partes = texto.split("-");
  return partes[2] + "/" + partes[1] + "/" + partes[0];
}

function sumarMeses(texto, meses) {
  const partes = texto.split("-");
  const anio = Number(partes[0]);
  const mes = Number(partes[1]);
  const dia = Number(partes[2]);

  let fecha = new Date(anio, mes - 1 + meses, dia);

  if (fecha.getDate() != dia) {
    fecha = new Date(anio, mes - 1 + meses + 1, 0);
  }
  return fechaATexto(fecha);
}

function estaActivo(miembro) {
  return miembro.fin >= hoy();
}


function mostrarTabla() {
  const textoBuscado = document.getElementById("q").value.trim();
  let html = "";

  for (let i = 0; i < miembros.length; i++) {
    const miembro = miembros[i];

    if (miembro.dni.includes(textoBuscado)) {

      let claseFila = "";
      if (i == posicionSeleccionada) {
        claseFila = "sel";
      }

      let estado = "No activo";
      let claseEstado = "off-b";
      if (estaActivo(miembro)) {
        estado = "Activo";
        claseEstado = "on-b";
      }

      html += "<tr class='" + claseFila + "' onclick='elegirFila(" + i + ")'>";
      html += "<td>" + miembro.nombres + " " + miembro.apellidos + "</td>";
      html += "<td>" + miembro.dni + "</td>";
      html += "<td>" + formatoFecha(miembro.inicio) + "</td>";
      html += "<td>" + formatoFecha(miembro.fin) + "</td>";
      html += "<td class='" + claseEstado + "'>" + estado + "</td>";
      html += "</tr>";
    }
  }

  if (html == "") {
    html = "<tr><td colspan='5'>No se encontraron miembros.</td></tr>";
  }
  document.getElementById("tb").innerHTML = html;
}

function elegirFila(posicion) {
  posicionSeleccionada = posicion;
  mostrarTabla();
}

document.getElementById("q").oninput = function () {
  posicionSeleccionada = -1;
  mostrarTabla();
};

function buscarMiembro() {
  if (posicionSeleccionada != -1) {
    return posicionSeleccionada;
  }
  const dniEscrito = document.getElementById("q").value.trim();
  for (let i = 0; i < miembros.length; i++) {
    if (miembros[i].dni == dniEscrito) {
      return i;
    }
  }
  return -1;
}

function mostrarLista() {
  document.getElementById("v-list").hidden = false;
  document.getElementById("v-form").hidden = true;
  document.getElementById("ttl").textContent = "Control de membresías";
  mostrarTabla();
}

function mostrarFormulario(titulo) {
  document.getElementById("v-list").hidden = true;
  document.getElementById("v-form").hidden = false;
  document.getElementById("ttl").textContent = titulo;
}


document.getElementById("bAsis").onclick = function () {
  const posicion = buscarMiembro();
  if (posicion == -1) {
    alert("Escribe un DNI registrado o selecciona un miembro de la tabla.");
    return;
  }
  const miembro = miembros[posicion];

  if (estaActivo(miembro) == false) {
    alert(miembro.nombres + " no tiene una membresía activa.");
    return;
  }

  for (let i = 0; i < miembro.asistencias.length; i++) {
    if (miembro.asistencias[i] == hoy()) {
      alert("La asistencia ya fue registrada.");
      return;
    }
  }

  miembro.asistencias.push(hoy());
  guardarMiembros();
  alert("Asistencia registrada: " + miembro.nombres + " " + miembro.apellidos);
};

let htmlPlanes = "";
for (let i = 0; i < planesMeses.length; i++) {
  htmlPlanes += "<button type='button' class='plan' id='plan" + planesMeses[i] + "' onclick='elegirPlan(" + planesMeses[i] + ")'>";
  htmlPlanes += planesMeses[i] + " meses<br>x<br>S/ " + planesPrecios[i];
  htmlPlanes += "</button>";
}
document.getElementById("planes").innerHTML = htmlPlanes;

function precioDelPlan(meses) {
  for (let i = 0; i < planesMeses.length; i++) {
    if (planesMeses[i] == meses) {
      return planesPrecios[i];
    }
  }
  return 0;
}

function marcarPlan() {
  for (let i = 0; i < planesMeses.length; i++) {
    const boton = document.getElementById("plan" + planesMeses[i]);
    if (planesMeses[i] == formulario.plan.value) {
      boton.classList.add("on");
    } else {
      boton.classList.remove("on");
    }
  }
}

function calcularPlan() {
  const meses = Number(formulario.plan.value);
  if (meses != 0 && formulario.inicio.value != "") {
    formulario.fin.value = sumarMeses(formulario.inicio.value, meses);
    formulario.monto.value = precioDelPlan(meses);
  }
  marcarPlan();
}

function elegirPlan(meses) {
  formulario.plan.value = meses;
  calcularPlan();
}

formulario.plan.onchange = calcularPlan;
formulario.inicio.onchange = calcularPlan;


// Botón Registrar miembro 
document.getElementById("bNew").onclick = function () {
  modo = "nuevo";
  formulario.reset();
  formulario.inicio.value = hoy();

  formulario.dni.disabled = false;
  formulario.nombres.disabled = false;
  formulario.apellidos.disabled = false;

  document.getElementById("bSave").textContent = "Registrar";
  marcarPlan();
  mostrarFormulario("Registro de membresía");
};

// Botón Renovar membresía
document.getElementById("bRenov").onclick = function () {
  const posicion = buscarMiembro();
  if (posicion == -1) {
    alert("Selecciona un miembro o escribe su DNI para renovar.");
    return;
  }
  posicionSeleccionada = posicion;
  const miembro = miembros[posicion];

  modo = "renovar";
  formulario.reset();
  formulario.dni.value = miembro.dni;
  formulario.nombres.value = miembro.nombres;
  formulario.apellidos.value = miembro.apellidos;

  if (estaActivo(miembro)) {
    formulario.inicio.value = miembro.fin;
  } else {
    formulario.inicio.value = hoy();
  }

  formulario.dni.disabled = true;
  formulario.nombres.disabled = true;
  formulario.apellidos.disabled = true;

  document.getElementById("bSave").textContent = "Actualizar";
  marcarPlan();
  mostrarFormulario("Renovar membresía");
};

// Botón Cancelar 
document.getElementById("bCancel").onclick = function (){
  mostrarLista();
};


formulario.onsubmit = function (evento){
  evento.preventDefault();

  const inicio = formulario.inicio.value;
  const fin = formulario.fin.value;
  const monto = Number(formulario.monto.value);

  if (fin <= inicio){
    alert("La fecha de fin debe ser posterior a la fecha de inicio.");
    return;
  }

  if (modo == "nuevo"){
    const dni = formulario.dni.value.trim();

    if (dni.length != 8 || isNaN(dni)){
      alert("El DNI debe tener 8 números.");
      return;
    }

    for (let i = 0; i < miembros.length; i++) {
      if (miembros[i].dni == dni) {
        alert("Ya existe un miembro con ese DNI.");
        return;
      }
    }

    const nuevoMiembro = {
      dni: dni,
      nombres: formulario.nombres.value.trim(),
      apellidos: formulario.apellidos.value.trim(),
      inicio: inicio,
      fin: fin,
      monto: monto,
      asistencias: []
    };
    miembros.push(nuevoMiembro);

  } else {
    miembros[posicionSeleccionada].inicio = inicio;
    miembros[posicionSeleccionada].fin = fin;
    miembros[posicionSeleccionada].monto = monto;
  }

  guardarMiembros();
  posicionSeleccionada = -1;
  document.getElementById("q").value = "";
  mostrarLista();
};

mostrarTabla();
