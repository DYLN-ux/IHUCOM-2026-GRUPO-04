if (localStorage.getItem("gym_alto_contraste") == "si") {
  document.documentElement.classList.add("alto-contraste");
}

document.addEventListener("DOMContentLoaded", function () {
  const boton = document.getElementById("btnContraste");

  // Cambiar texto.
  function actualizarBoton() {
    const activo = document.documentElement.classList.contains("alto-contraste");
    if (activo) {
      boton.textContent = "Volver al modo normal";
    } else {
      boton.textContent = "Alto contraste y texto grande";
    }
    boton.setAttribute("aria-pressed", activo);
  }

  // Botón presionado
  boton.onclick = function () {
    document.documentElement.classList.toggle("alto-contraste");
    if (document.documentElement.classList.contains("alto-contraste")) {
      localStorage.setItem("gym_alto_contraste", "si");
    } else {
      localStorage.removeItem("gym_alto_contraste");
    }
    actualizarBoton();
  };

  actualizarBoton();
});
