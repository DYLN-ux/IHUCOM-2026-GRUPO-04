const usuarios = [
  {usuario: "Stephany", clave: "12345678", nombre: "Stephany Gómez"},
  {usuario: "Sebastian", clave: "12345", nombre: "Sebastian Camargo"},
  {usuario: "Hade", clave: "12345", nombre: "Hade Coronado"},
  {usuario: "Dylan", clave: "12345", nombre: "Dylan Tejeda"},
  {usuario: "Kelly", clave: "12345", nombre: "Kelly Bello"},
  {usuario: "Lorena", clave: "12345", nombre: "Lorena Huanca"}
];

if (sessionStorage.getItem("megax_usuario") != null) {
  window.location.href = "membresias.html";
}

const formulario = document.getElementById("f");
const mensajeError = document.getElementById("err");

formulario.onsubmit = function(evento) {
  evento.preventDefault(); 

  const usuarioEscrito = document.getElementById("user").value.trim().toLowerCase();
  const claveEscrita = document.getElementById("pass").value;

  let usuarioEncontrado = null;
  for (let i = 0; i < usuarios.length; i++) {
    const nombreCorrecto = usuarios[i].usuario.toLowerCase() == usuarioEscrito;
    const claveCorrecta = usuarios[i].clave == claveEscrita;
    if (nombreCorrecto && claveCorrecta) {
      usuarioEncontrado = usuarios[i];
    }
  }

  if (usuarioEncontrado != null) {
    
    sessionStorage.setItem("megax_usuario", usuarioEncontrado.nombre);
    window.location.href = "membresias.html";

  } else {
    mensajeError.textContent = "Usuario o contraseña incorrectos";
  }
};
